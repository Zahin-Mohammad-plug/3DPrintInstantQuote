import { Routes, Route } from "react-router-dom"
import { Toaster } from "./components/ui/toaster"
import HomePage from "./pages/HomePage"
import UploadPage from "./pages/UploadPage"
import CustomizePage from "./pages/CustomizePage"
import QuotePage from "./pages/QuotePage"
import CartPage from "./pages/CartPage"
import CheckoutPage from "./pages/CheckoutPage"
import CatalogPage from "./pages/CatalogPage"
import CategoryPage from "./pages/CategoryPage"
import ProductPage from "./pages/ProductPage"
import ServicePage from "./pages/ServicePage"
import ContactPage from "./pages/ContactPage"
import AboutPage from "./pages/AboutPage"
import AdminPage from "./pages/AdminPage"

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/upload" element={<UploadPage />} />
        <Route path="/customize" element={<CustomizePage />} />
        <Route path="/quote" element={<QuotePage />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/catalog" element={<CatalogPage />} />
        <Route path="/catalog/:category" element={<CategoryPage />} />
        <Route path="/catalog/product/:id" element={<ProductPage />} />
        <Route path="/services/3d-printing" element={<ServicePage type="3d-printing" />} />
        <Route path="/services/print-on-demand" element={<ServicePage type="print-on-demand" />} />
        <Route path="/services/3d-modeling" element={<ServicePage type="3d-modeling" />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/admin" element={<AdminPage />} />
      </Routes>
      <Toaster />
    </>
  )
}

export default App
