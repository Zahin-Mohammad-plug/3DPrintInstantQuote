"use client"

import { useState, useEffect } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { getMaterials } from "@/services/api"

export function QualitySelector({ onSelect, selectedQuality }) {
  const [qualityLevels, setQualityLevels] = useState([
    {
      id: "draft",
      name: "Draft",
      layer_height: "0.3mm",
      description: "Faster printing, visible layer lines",
      price_modifier: -5,
    },
    {
      id: "standard",
      name: "Standard",
      layer_height: "0.2mm",
      description: "Balanced quality and speed",
      price_modifier: 0,
    },
    {
      id: "high",
      name: "High Quality",
      layer_height: "0.1mm",
      description: "Finer details, smoother finish",
      price_modifier: 10,
    },
    {
      id: "ultra",
      name: "Ultra Fine",
      layer_height: "0.05mm",
      description: "Maximum detail, longest print time",
      price_modifier: 15,
    },
  ])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadQualityLevels() {
      try {
        const materialsData = await getMaterials()

        // If quality levels are defined in the API response, use those
        if (
          materialsData.global_settings &&
          materialsData.global_settings.quality_levels &&
          materialsData.global_settings.quality_levels.length > 0
        ) {
          setQualityLevels(materialsData.global_settings.quality_levels)
        }

        setIsLoading(false)
      } catch (error) {
        console.error("Failed to load quality levels:", error)
        setIsLoading(false)
      }
    }

    loadQualityLevels()
  }, [])

  const handleQualitySelect = (qualityId) => {
    onSelect(qualityId)
  }

  if (isLoading) {
    return <div className="text-center py-4">Loading quality options...</div>
  }

  return (
    <RadioGroup
      value={selectedQuality || "standard"}
      onValueChange={handleQualitySelect}
      className="grid grid-cols-1 gap-3"
    >
      {qualityLevels.map((quality) => (
        <div key={quality.id}>
          <RadioGroupItem value={quality.id} id={`quality-${quality.id}`} className="peer sr-only" />
          <Label
            htmlFor={`quality-${quality.id}`}
            className="flex flex-col rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
          >
            <div className="flex justify-between items-center mb-1">
              <span className="font-medium">{quality.name}</span>
              <span className="text-xs bg-muted px-2 py-1 rounded">{quality.layer_height} layers</span>
            </div>
            <p className="text-sm text-muted-foreground">{quality.description}</p>
            <div className="mt-2 text-xs">
              {quality.price_modifier > 0 && (
                <span className="text-destructive">+${quality.price_modifier.toFixed(2)}</span>
              )}
              {quality.price_modifier < 0 && (
                <span className="text-green-600">-${Math.abs(quality.price_modifier).toFixed(2)}</span>
              )}
              {quality.price_modifier === 0 && <span className="text-muted-foreground">No additional cost</span>}
            </div>
          </Label>
        </div>
      ))}
    </RadioGroup>
  )
}
