"use client"

import { useState, useEffect } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"
import { getMaterials } from "@/services/api"

export function ColorSelector({ onSelect, selectedColor, selectedSpecialFilament, onMultiColorChange }) {
  const [colors, setColors] = useState([])
  const [specialFilaments, setSpecialFilaments] = useState([])
  const [isMultiColor, setIsMultiColor] = useState(false)
  const [multiColorDetails, setMultiColorDetails] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadColors() {
      try {
        const materialsData = await getMaterials()

        // Extract colors from the first material (usually PLA has the most colors)
        const firstMaterial = materialsData.materials[0]
        if (firstMaterial && firstMaterial.colors) {
          setColors(firstMaterial.colors)
        }

        // Extract special filaments if available
        if (materialsData.special_filaments) {
          setSpecialFilaments(materialsData.special_filaments)
        }

        setIsLoading(false)
      } catch (error) {
        console.error("Failed to load colors:", error)
        setIsLoading(false)
      }
    }

    loadColors()
  }, [])

  const handleColorSelect = (colorHex) => {
    onSelect(colorHex)
    setIsMultiColor(false)
    if (onMultiColorChange) {
      onMultiColorChange(false)
    }
  }

  const handleSpecialFilamentSelect = (filamentId) => {
    const filament = specialFilaments.find((f) => f.id === filamentId)
    onSelect(null, true, filamentId)
    setIsMultiColor(false)
    if (onMultiColorChange) {
      onMultiColorChange(false)
    }
  }

  const handleMultiColorChange = (checked) => {
    setIsMultiColor(checked)
    if (onMultiColorChange) {
      onMultiColorChange(checked, multiColorDetails)
    }

    // If multi-color is selected, deselect any other color
    if (checked) {
      onSelect(null)
    }
  }

  const handleMultiColorDetailsChange = (e) => {
    setMultiColorDetails(e.target.value)
    if (onMultiColorChange) {
      onMultiColorChange(isMultiColor, e.target.value)
    }
  }

  if (isLoading) {
    return <div className="text-center py-4">Loading color options...</div>
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Checkbox id="multi-color" checked={isMultiColor} onCheckedChange={handleMultiColorChange} />
          <Label htmlFor="multi-color">Multi-Color Print (Additional charges apply)</Label>
        </div>

        {isMultiColor && (
          <div className="space-y-2 pl-6">
            <Label htmlFor="multi-color-details">Please describe your multi-color requirements:</Label>
            <Textarea
              id="multi-color-details"
              placeholder="Describe which parts should be which colors..."
              value={multiColorDetails}
              onChange={handleMultiColorDetailsChange}
            />
            <Alert className="bg-muted">
              <InfoIcon className="h-4 w-4" />
              <AlertDescription>
                Our team will review your multi-color request and may contact you to confirm details before printing.
              </AlertDescription>
            </Alert>
          </div>
        )}
      </div>

      {!isMultiColor && (
        <>
          <div className="space-y-2">
            <Label>Standard Colors</Label>
            <RadioGroup
              value={selectedColor || ""}
              onValueChange={handleColorSelect}
              className="grid grid-cols-2 sm:grid-cols-3 gap-2"
            >
              {colors.map((color) => (
                <div key={color.id}>
                  <RadioGroupItem value={color.hex} id={`color-${color.id}`} className="peer sr-only" />
                  <Label
                    htmlFor={`color-${color.id}`}
                    className="flex items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded-full border" style={{ backgroundColor: color.hex }} />
                      {color.name}
                    </div>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {specialFilaments.length > 0 && (
            <div className="space-y-2">
              <Label>Special Filaments</Label>
              <RadioGroup
                value={selectedSpecialFilament || ""}
                onValueChange={handleSpecialFilamentSelect}
                className="grid grid-cols-1 sm:grid-cols-2 gap-2"
              >
                {specialFilaments.map((filament) => (
                  <div key={filament.id}>
                    <RadioGroupItem value={filament.id} id={`filament-${filament.id}`} className="peer sr-only" />
                    <Label
                      htmlFor={`filament-${filament.id}`}
                      className="flex items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                    >
                      <div className="flex flex-col">
                        <span>{filament.name}</span>
                        <span className="text-xs text-muted-foreground">+${filament.priceModifier.toFixed(2)}</span>
                      </div>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}
        </>
      )}
    </div>
  )
}
