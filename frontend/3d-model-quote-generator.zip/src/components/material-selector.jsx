"use client"

import { useState, useEffect } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"
import { getMaterials } from "@/services/api"

export function MaterialSelector({ onSelect, selectedMaterial, selectedColor, isMultiColor }) {
  const [materials, setMaterials] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function loadMaterials() {
      try {
        const materialsData = await getMaterials()
        if (materialsData.materials) {
          setMaterials(materialsData.materials)
        }
        setIsLoading(false)
      } catch (error) {
        console.error("Failed to load materials:", error)
        setError("Failed to load materials. Please try again later.")
        setIsLoading(false)
      }
    }

    loadMaterials()
  }, [])

  const handleMaterialSelect = (materialId) => {
    onSelect(materialId)
  }

  // Check if the selected color is available for a material
  const isColorAvailableForMaterial = (material) => {
    if (!selectedColor || isMultiColor) return true

    return material.colors.some((color) => color.hex.toLowerCase() === selectedColor.toLowerCase())
  }

  if (isLoading) {
    return <div className="text-center py-4">Loading material options...</div>
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-4">
      <RadioGroup
        value={selectedMaterial || ""}
        onValueChange={handleMaterialSelect}
        className="grid grid-cols-1 gap-3"
      >
        {materials.map((material) => {
          const isColorAvailable = isColorAvailableForMaterial(material)

          return (
            <div key={material.id}>
              <RadioGroupItem
                value={material.id}
                id={`material-${material.id}`}
                className="peer sr-only"
                disabled={!isColorAvailable && !isMultiColor}
              />
              <Label
                htmlFor={`material-${material.id}`}
                className={`flex flex-col rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer ${
                  !isColorAvailable && !isMultiColor ? "opacity-50 cursor-not-allowed" : ""
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium">{material.name}</span>
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                    {material.id === "PLA"
                      ? "Decorative"
                      : material.id === "PETG"
                        ? "Outdoor Use"
                        : material.id === "ABS"
                          ? "Commercial Grade"
                          : "Standard"}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{material.description}</p>
                <div className="flex flex-wrap gap-1">
                  {material.properties.map((property, index) => (
                    <span key={index} className="text-xs bg-muted px-2 py-1 rounded">
                      {property}
                    </span>
                  ))}
                </div>
                {!isColorAvailable && !isMultiColor && (
                  <p className="text-xs text-destructive mt-2">Selected color not available in this material</p>
                )}
              </Label>
            </div>
          )
        })}
      </RadioGroup>

      {isMultiColor && (
        <Alert className="bg-muted">
          <InfoIcon className="h-4 w-4" />
          <AlertDescription>
            For multi-color prints, we'll use the appropriate material for each color based on your requirements.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
