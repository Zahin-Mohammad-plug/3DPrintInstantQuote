"use client"

import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export function CartIcon() {
  const [itemCount, setItemCount] = useState(0)

  useEffect(() => {
    // Initial count from session storage
    const updateCartCount = () => {
      const cart = sessionStorage.getItem("cart")
      if (cart) {
        try {
          const cartItems = JSON.parse(cart)
          setItemCount(Array.isArray(cartItems) ? cartItems.length : 0)
        } catch (error) {
          console.error("Error parsing cart data:", error)
          setItemCount(0)
        }
      } else {
        setItemCount(0)
      }
    }

    // Update count on mount
    updateCartCount()

    // Listen for cart updates
    window.addEventListener("cartUpdated", updateCartCount)

    // Cleanup
    return () => {
      window.removeEventListener("cartUpdated", updateCartCount)
    }
  }, [])

  return (
    <Button variant="ghost" size="icon" asChild>
      <Link to="/cart" className="relative">
        <ShoppingCart className="h-5 w-5" />
        {itemCount > 0 && (
          <Badge
            variant="destructive"
            className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
          >
            {itemCount}
          </Badge>
        )}
        <span className="sr-only">Cart</span>
      </Link>
    </Button>
  )
}
