"use client"

import { useEffect, useRef, useState } from "react"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Stage } from "@react-three/drei"
import { STLLoader } from "three/examples/jsm/loaders/STLLoader"
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader"
import { ThreeMFLoader } from "three/examples/jsm/loaders/3MFLoader"
import * as THREE from "three"
import { Loader2 } from "lucide-react"

function Model({ url, color, material }) {
  const [model, setModel] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!url || url === "fallback") return

    const loadModel = async () => {
      try {
        const fileExtension = url.split(".").pop().toLowerCase()
        let geometry

        if (fileExtension === "stl") {
          const loader = new STLLoader()
          geometry = await new Promise((resolve, reject) => {
            loader.load(url, resolve, undefined, reject)
          })
        } else if (fileExtension === "obj") {
          const loader = new OBJLoader()
          const object = await new Promise((resolve, reject) => {
            loader.load(url, resolve, undefined, reject)
          })
          // For OBJ we return the object directly
          setModel(object)
          return
        } else if (fileExtension === "3mf") {
          const loader = new ThreeMFLoader()
          const object = await new Promise((resolve, reject) => {
            loader.load(url, resolve, undefined, reject)
          })
          // For 3MF we return the object directly
          setModel(object)
          return
        } else {
          throw new Error(`Unsupported file format: ${fileExtension}`)
        }

        // For STL we need to create a mesh
        const materialColor = new THREE.Color(color || "#cccccc")
        let meshMaterial

        // Set material properties based on selected material
        if (material === "PLA") {
          meshMaterial = new THREE.MeshStandardMaterial({
            color: materialColor,
            roughness: 0.5,
            metalness: 0.1,
          })
        } else if (material === "PETG") {
          meshMaterial = new THREE.MeshStandardMaterial({
            color: materialColor,
            roughness: 0.3,
            metalness: 0.2,
            transparent: true,
            opacity: 0.9,
          })
        } else if (material === "ABS") {
          meshMaterial = new THREE.MeshStandardMaterial({
            color: materialColor,
            roughness: 0.7,
            metalness: 0.1,
          })
        } else {
          // Default material
          meshMaterial = new THREE.MeshStandardMaterial({
            color: materialColor,
            roughness: 0.5,
            metalness: 0.1,
          })
        }

        const mesh = new THREE.Mesh(geometry, meshMaterial)

        // Center the model
        const box = new THREE.Box3().setFromObject(mesh)
        const center = box.getCenter(new THREE.Vector3())
        mesh.position.sub(center)

        setModel(mesh)
      } catch (err) {
        console.error("Error loading model:", err)
        setError(err.message || "Failed to load model")
      }
    }

    loadModel()
  }, [url, color, material])

  if (error) {
    return null // Error will be displayed by parent component
  }

  return model ? <primitive object={model} /> : null
}

export function ModelViewer({
  modelPath,
  color = "#cccccc",
  material = "PLA",
  jobId,
  isLoading = false,
  viewerTheme = "dark",
}) {
  const containerRef = useRef(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })

  useEffect(() => {
    if (containerRef.current) {
      const { clientWidth, clientHeight } = containerRef.current
      setDimensions({ width: clientWidth, height: clientHeight })
    }
  }, [])

  return (
    <div
      ref={containerRef}
      className="model-viewer-container"
      style={{
        backgroundColor: viewerTheme === "dark" ? "#1a1a1a" : "#f5f5f5",
        height: "100%",
        width: "100%",
        position: "relative",
      }}
    >
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <div className="bg-background/80 p-4 rounded-md flex items-center gap-2">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
            <span>Loading model...</span>
          </div>
        </div>
      )}

      {!isLoading && modelPath && modelPath !== "fallback" && (
        <Canvas shadows camera={{ position: [0, 0, 5], fov: 50 }}>
          <Stage environment={viewerTheme === "dark" ? "night" : "city"} intensity={0.5}>
            <Model url={modelPath} color={color} material={material} />
          </Stage>
          <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
        </Canvas>
      )}

      {!isLoading && (!modelPath || modelPath === "fallback") && (
        <div className="absolute inset-0 flex items-center justify-center">
          <p className="text-muted-foreground">No model to display</p>
        </div>
      )}
    </div>
  )
}
