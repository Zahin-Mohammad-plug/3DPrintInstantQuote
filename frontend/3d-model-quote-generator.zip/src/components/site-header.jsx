"use client"

import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { CartIcon } from "@/components/cart-icon"
import { Menu } from "lucide-react"
import { useState } from "react"

export function SiteHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center space-x-2">
            <span className="font-bold text-xl">3D PrintQuote</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link to="/upload" className="text-sm font-medium transition-colors hover:text-primary">
              Upload
            </Link>
            <Link to="/catalog" className="text-sm font-medium transition-colors hover:text-primary">
              Catalog
            </Link>
            <div className="relative group">
              <span className="text-sm font-medium transition-colors hover:text-primary cursor-pointer">Services</span>
              <div className="absolute left-0 top-full hidden group-hover:block bg-background border rounded-md shadow-md p-2 min-w-[200px] z-50">
                <Link to="/services/3d-printing" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  3D Printing
                </Link>
                <Link to="/services/print-on-demand" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  Print on Demand
                </Link>
                <Link to="/services/3d-modeling" className="block px-3 py-2 text-sm hover:bg-muted rounded-md">
                  3D Modeling
                </Link>
              </div>
            </div>
            <Link to="/about" className="text-sm font-medium transition-colors hover:text-primary">
              About
            </Link>
            <Link to="/contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <CartIcon />
          <ThemeToggle />
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden border-t p-4 bg-background">
          <nav className="flex flex-col space-y-3">
            <Link
              to="/upload"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setIsMenuOpen(false)}
            >
              Upload
            </Link>
            <Link
              to="/catalog"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setIsMenuOpen(false)}
            >
              Catalog
            </Link>
            <Link
              to="/services/3d-printing"
              className="text-sm font-medium transition-colors hover:text-primary pl-4"
              onClick={() => setIsMenuOpen(false)}
            >
              3D Printing
            </Link>
            <Link
              to="/services/print-on-demand"
              className="text-sm font-medium transition-colors hover:text-primary pl-4"
              onClick={() => setIsMenuOpen(false)}
            >
              Print on Demand
            </Link>
            <Link
              to="/services/3d-modeling"
              className="text-sm font-medium transition-colors hover:text-primary pl-4"
              onClick={() => setIsMenuOpen(false)}
            >
              3D Modeling
            </Link>
            <Link
              to="/about"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link
              to="/contact"
              className="text-sm font-medium transition-colors hover:text-primary"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
