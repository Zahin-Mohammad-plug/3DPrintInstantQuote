"use client"

import { useState, useCallback } from "react"
import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, AlertCircle } from "lucide-react"
import { uploadModel } from "@/services/api"

export function FileUploader() {
  const navigate = useNavigate()
  const [file, setFile] = useState(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError] = useState(null)

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0]
    if (selectedFile) {
      setFile(selectedFile)
      setError(null)
    }
  }

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile) {
      setFile(droppedFile)
      setError(null)
    }
  }, [])

  const handleDragOver = useCallback((e) => {
    e.preventDefault()
  }, [])

  const handleUpload = async () => {
    if (!file) {
      setError("Please select a file to upload")
      return
    }

    // Check file extension
    const fileExt = file.name.split(".").pop().toLowerCase()
    const supportedFormats = ["stl", "obj", "3mf", "step"]

    if (!supportedFormats.includes(fileExt)) {
      setError(`Unsupported file format. Please upload a ${supportedFormats.join(", ")} file.`)
      return
    }

    setIsUploading(true)
    setUploadProgress(0)
    setError(null)

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          const newProgress = prev + 10
          return newProgress >= 90 ? 90 : newProgress
        })
      }, 500)

      const result = await uploadModel({ file })

      clearInterval(progressInterval)
      setUploadProgress(100)

      // Store job ID and model name in sessionStorage
      sessionStorage.setItem("uploadedModel", file.name)
      sessionStorage.setItem("uploadedModelJobId", result.job_id)

      // Navigate to customize page
      setTimeout(() => {
        navigate("/customize")
      }, 500)
    } catch (err) {
      setError(err.message || "Failed to upload file")
      setIsUploading(false)
      setUploadProgress(0)
    }
  }

  return (
    <Card className="border-2 border-dashed">
      <div className="p-6 text-center" onDrop={handleDrop} onDragOver={handleDragOver}>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="mb-4">
          <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
          <p className="mt-2 text-sm text-muted-foreground">
            Drag and drop your 3D model file here, or click to browse
          </p>
        </div>

        <input
          type="file"
          id="file-upload"
          className="hidden"
          accept=".stl,.obj,.3mf,.step"
          onChange={handleFileChange}
        />

        <div className="flex justify-center gap-2">
          <Button
            variant="outline"
            onClick={() => document.getElementById("file-upload").click()}
            disabled={isUploading}
          >
            Browse Files
          </Button>

          <Button onClick={handleUpload} disabled={!file || isUploading}>
            {isUploading ? "Uploading..." : "Upload"}
          </Button>
        </div>

        {file && (
          <p className="mt-2 text-sm">
            Selected: <span className="font-medium">{file.name}</span>
          </p>
        )}

        {isUploading && (
          <div className="mt-4">
            <Progress value={uploadProgress} className="h-2" />
            <p className="mt-1 text-xs text-muted-foreground">
              {uploadProgress < 100 ? "Uploading and processing..." : "Upload complete!"}
            </p>
          </div>
        )}
      </div>
    </Card>
  )
}
