"use client"

import { useState, useEffect, useCallback } from "react"

const TOAST_LIMIT = 5
const TOAST_REMOVE_DELAY = 1000000

let count = 0

function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER
  return count.toString()
}

const toastTimeouts = new Map()

export const useToast = () => {
  const [toasts, setToasts] = useState([])

  const dismiss = useCallback((toastId) => {
    setToasts((toasts) => toasts.map((toast) => (toast.id === toastId ? { ...toast, open: false } : toast)))
  }, [])

  const dismissAll = useCallback(() => {
    setToasts((toasts) =>
      toasts.map((toast) => ({
        ...toast,
        open: false,
      })),
    )
  }, [])

  const update = useCallback((toastId, data) => {
    setToasts((toasts) => toasts.map((toast) => (toast.id === toastId ? { ...toast, ...data } : toast)))
  }, [])

  const create = useCallback(
    (data) => {
      const id = genId()

      const newToast = {
        id,
        open: true,
        ...data,
        onOpenChange: (open) => {
          if (!open) dismiss(id)
        },
      }

      setToasts((toasts) => {
        const updatedToasts = [newToast, ...toasts].slice(0, TOAST_LIMIT)
        return updatedToasts
      })

      return id
    },
    [dismiss],
  )

  const toast = useCallback(
    (props) => {
      return create(props)
    },
    [create],
  )

  useEffect(() => {
    toasts.forEach((toast) => {
      if (!toast.open && !toastTimeouts.has(toast.id)) {
        const timeout = setTimeout(() => {
          setToasts((toasts) => toasts.filter((t) => t.id !== toast.id))
          toastTimeouts.delete(toast.id)
        }, TOAST_REMOVE_DELAY)

        toastTimeouts.set(toast.id, timeout)
      }
    })

    return () => {
      toastTimeouts.forEach((timeout) => {
        clearTimeout(timeout)
      })
    }
  }, [toasts])

  return {
    toasts,
    toast,
    dismiss,
    dismissAll,
    update,
  }
}
